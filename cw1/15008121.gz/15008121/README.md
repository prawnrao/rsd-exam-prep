Alchemist
---------

This is a package which allows you to run experiments on chemicals held within a laboratory with 2 shelves. 

Usage:

Invoke tool with 'abracadabra <yaml_file>'