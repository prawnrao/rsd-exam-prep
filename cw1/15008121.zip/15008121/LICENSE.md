(C) Pranav Rao 2018

This "alchemist" package is granted into the public domain.